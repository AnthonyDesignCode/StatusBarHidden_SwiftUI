//
//  ContentView.swift
//  StatusBarHidden_SwiftUI
//
//  Created by Immature Inc on 29/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    // first create a private var
    @State private var isOn = true
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Status Bar Hidden")
                .font(.largeTitle)
            // we are now going to create a toggle we are going to add some text and two images from the sf symbols app we are going to display one image when the toggle isOn and one when the toggle is off.
            Toggle(isOn: $isOn) {
                Text("Status Bar Hidden")
                Image(systemName: isOn ? "eye.slash" : "eye")
                    .foregroundColor(.red)
            }.padding()
        }.font(.title)
            //We can use this on any view.
        .statusBar(hidden: isOn)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
